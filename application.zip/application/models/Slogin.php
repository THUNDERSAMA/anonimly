<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class SLogin extends CI_Model
{
   
    function getIPAddress() {  
        //file_put_contents("testz.txt","validate1");
        //whether ip is from the share internet  
    //      if(!emptyempty($_SERVER['HTTP_CLIENT_IP'])) {  
    //                 $ip = $_SERVER['HTTP_CLIENT_IP'];  
    //         }  
    //     //whether ip is from the proxy  
    //     elseif (!emptyempty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
    //                 $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
    //      }  
    // //whether ip is from the remote address  
    //     else{  
    //              $ip = $_SERVER['REMOTE_ADDR'];  
    //      }  
    //      return $ip;  
    
    } 
   

    /*function to use fetch the data from users table*/
    function validate($user, $pass)
    {
      
       // echo('<script>console.log("hello");</script>');
        $user = trim($user);
        $km=$user;
        $user=base64_encode($user);
        $users=base64_encode($user);
$pass = trim($pass);

$pass=base64_encode($km).$pass.base64_encode($km);
$hpass= hash('sha256', $pass);

$ip =  $this->input->ip_address();
file_put_contents("testz.txt",$ip);
$ip=base64_encode($ip);

$sqlz="SELECT * FROM maskers WHERE MASKING_ID='".$user."'";  
$queryz = $this->db->query($sqlz);
$resz = $queryz->result();
if(count($resz) == 0)
{
    
        $sql="INSERT INTO  users (EMAIL,PASSWORDS,IP_ADDRESS,MASKING_ID)
        VALUES ('".$users."', '".$hpass."', '".$ip."','".$user."')";  
        $query = $this->db->query($sql);
        //$res = $query->result();
        if($query)
        {
            $sqls="INSERT INTO  maskers (MASKING_ID,CID,SIID,DELETED,M_TIMES)
            VALUES ('".$user."', '".$user."', '".$user."','0','".$hpass."')";  
            $querys = $this->db->query($sqls);
            //$res = $query->result();
            //update php admins set default then run
            if($querys)
            {
    $res=1;
            }
            else{
                $res=2;
            echo "Error: " . $sqls . "<br>" . $this->db->error();
        }
    }
    else{
        $res=3;
        echo "Error: " . $sql . "<br>" . $this->db->error();
    } 
}
else{
    $res=5;
}
        return $res;
    }
}