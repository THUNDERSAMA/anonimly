<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-04-01 22:42:41 --> Severity: Notice --> Undefined index: auth C:\xampp2\htdocs\anonimly\application\controllers\MainController.php 53
ERROR - 2023-04-01 22:42:41 --> Severity: error --> Exception: Too few arguments to function Feedmain::createpost(), 1 passed in C:\xampp2\htdocs\anonimly\application\controllers\MainController.php on line 60 and exactly 2 expected C:\xampp2\htdocs\anonimly\application\models\Feedmain.php 10
ERROR - 2023-04-01 22:47:15 --> Severity: error --> Exception: Too few arguments to function Feedmain::createpost(), 1 passed in C:\xampp2\htdocs\anonimly\application\controllers\MainController.php on line 60 and exactly 2 expected C:\xampp2\htdocs\anonimly\application\models\Feedmain.php 10
INFO - 2023-04-01 22:48:32 --> Config Class Initialized
INFO - 2023-04-01 22:48:32 --> Hooks Class Initialized
DEBUG - 2023-04-01 22:48:32 --> UTF-8 Support Enabled
INFO - 2023-04-01 22:48:32 --> Utf8 Class Initialized
INFO - 2023-04-01 22:48:32 --> URI Class Initialized
INFO - 2023-04-01 22:48:32 --> Router Class Initialized
INFO - 2023-04-01 22:48:32 --> Output Class Initialized
INFO - 2023-04-01 22:48:32 --> Security Class Initialized
DEBUG - 2023-04-01 22:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 22:48:32 --> Input Class Initialized
INFO - 2023-04-01 22:48:32 --> Language Class Initialized
INFO - 2023-04-01 22:48:32 --> Loader Class Initialized
INFO - 2023-04-01 22:48:32 --> Helper loaded: url_helper
INFO - 2023-04-01 22:48:32 --> Helper loaded: form_helper
INFO - 2023-04-01 22:48:32 --> Helper loaded: file_helper
INFO - 2023-04-01 22:48:32 --> Helper loaded: cookie_helper
INFO - 2023-04-01 22:48:32 --> Database Driver Class Initialized
DEBUG - 2023-04-01 22:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 22:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 22:48:32 --> Form Validation Class Initialized
INFO - 2023-04-01 22:48:32 --> Controller Class Initialized
DEBUG - 2023-04-01 22:48:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-04-01 22:48:32 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-01 22:48:32 --> Model "MLogin" initialized
INFO - 2023-04-01 22:48:33 --> Model "Feedmain" initialized
ERROR - 2023-04-01 22:48:33 --> Severity: error --> Exception: Too few arguments to function Feedmain::createpost(), 1 passed in C:\xampp2\htdocs\anonimly\application\controllers\MainController.php on line 60 and exactly 2 expected C:\xampp2\htdocs\anonimly\application\models\Feedmain.php 10
INFO - 2023-04-01 22:49:10 --> Config Class Initialized
INFO - 2023-04-01 22:49:10 --> Hooks Class Initialized
DEBUG - 2023-04-01 22:49:10 --> UTF-8 Support Enabled
INFO - 2023-04-01 22:49:10 --> Utf8 Class Initialized
INFO - 2023-04-01 22:49:10 --> URI Class Initialized
INFO - 2023-04-01 22:49:10 --> Router Class Initialized
INFO - 2023-04-01 22:49:10 --> Output Class Initialized
INFO - 2023-04-01 22:49:10 --> Security Class Initialized
DEBUG - 2023-04-01 22:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 22:49:10 --> Input Class Initialized
INFO - 2023-04-01 22:49:10 --> Language Class Initialized
INFO - 2023-04-01 22:49:10 --> Loader Class Initialized
INFO - 2023-04-01 22:49:10 --> Helper loaded: url_helper
INFO - 2023-04-01 22:49:10 --> Helper loaded: form_helper
INFO - 2023-04-01 22:49:10 --> Helper loaded: file_helper
INFO - 2023-04-01 22:49:10 --> Helper loaded: cookie_helper
INFO - 2023-04-01 22:49:10 --> Database Driver Class Initialized
DEBUG - 2023-04-01 22:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 22:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 22:49:10 --> Form Validation Class Initialized
INFO - 2023-04-01 22:49:10 --> Controller Class Initialized
DEBUG - 2023-04-01 22:49:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-04-01 22:49:10 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-01 22:49:10 --> Model "MLogin" initialized
INFO - 2023-04-01 22:49:10 --> Model "Feedmain" initialized
INFO - 2023-04-01 22:49:10 --> Final output sent to browser
DEBUG - 2023-04-01 22:49:10 --> Total execution time: 0.0772
INFO - 2023-04-01 22:54:30 --> Config Class Initialized
INFO - 2023-04-01 22:54:30 --> Hooks Class Initialized
DEBUG - 2023-04-01 22:54:30 --> UTF-8 Support Enabled
INFO - 2023-04-01 22:54:30 --> Utf8 Class Initialized
INFO - 2023-04-01 22:54:31 --> URI Class Initialized
DEBUG - 2023-04-01 22:54:31 --> No URI present. Default controller set.
INFO - 2023-04-01 22:54:31 --> Router Class Initialized
INFO - 2023-04-01 22:54:31 --> Output Class Initialized
INFO - 2023-04-01 22:54:31 --> Security Class Initialized
DEBUG - 2023-04-01 22:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 22:54:31 --> Input Class Initialized
INFO - 2023-04-01 22:54:31 --> Language Class Initialized
INFO - 2023-04-01 22:54:31 --> Loader Class Initialized
INFO - 2023-04-01 22:54:31 --> Helper loaded: url_helper
INFO - 2023-04-01 22:54:31 --> Helper loaded: form_helper
INFO - 2023-04-01 22:54:31 --> Helper loaded: file_helper
INFO - 2023-04-01 22:54:31 --> Helper loaded: cookie_helper
INFO - 2023-04-01 22:54:31 --> Database Driver Class Initialized
DEBUG - 2023-04-01 22:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 22:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 22:54:31 --> Form Validation Class Initialized
INFO - 2023-04-01 22:54:31 --> Controller Class Initialized
DEBUG - 2023-04-01 22:54:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-04-01 22:54:31 --> Model "MLogin" initialized
INFO - 2023-04-01 22:54:31 --> Model "SLogin" initialized
INFO - 2023-04-01 22:54:31 --> File loaded: C:\xampp2\htdocs\anonimly\application\views\main.php
INFO - 2023-04-01 22:54:31 --> Final output sent to browser
DEBUG - 2023-04-01 22:54:31 --> Total execution time: 0.0950
INFO - 2023-04-01 22:57:03 --> Config Class Initialized
INFO - 2023-04-01 22:57:03 --> Hooks Class Initialized
DEBUG - 2023-04-01 22:57:03 --> UTF-8 Support Enabled
INFO - 2023-04-01 22:57:03 --> Utf8 Class Initialized
INFO - 2023-04-01 22:57:03 --> URI Class Initialized
INFO - 2023-04-01 22:57:03 --> Router Class Initialized
INFO - 2023-04-01 22:57:03 --> Output Class Initialized
INFO - 2023-04-01 22:57:03 --> Security Class Initialized
DEBUG - 2023-04-01 22:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 22:57:03 --> Input Class Initialized
INFO - 2023-04-01 22:57:03 --> Language Class Initialized
INFO - 2023-04-01 22:57:03 --> Loader Class Initialized
INFO - 2023-04-01 22:57:03 --> Helper loaded: url_helper
INFO - 2023-04-01 22:57:03 --> Helper loaded: form_helper
INFO - 2023-04-01 22:57:03 --> Helper loaded: file_helper
INFO - 2023-04-01 22:57:03 --> Helper loaded: cookie_helper
INFO - 2023-04-01 22:57:03 --> Database Driver Class Initialized
DEBUG - 2023-04-01 22:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 22:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 22:57:03 --> Form Validation Class Initialized
INFO - 2023-04-01 22:57:03 --> Controller Class Initialized
DEBUG - 2023-04-01 22:57:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-04-01 22:57:03 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-01 22:57:03 --> Model "MLogin" initialized
INFO - 2023-04-01 22:57:03 --> Model "Feedmain" initialized
INFO - 2023-04-01 22:57:03 --> Final output sent to browser
DEBUG - 2023-04-01 22:57:03 --> Total execution time: 0.0760
INFO - 2023-04-01 22:57:17 --> Config Class Initialized
INFO - 2023-04-01 22:57:17 --> Hooks Class Initialized
DEBUG - 2023-04-01 22:57:17 --> UTF-8 Support Enabled
INFO - 2023-04-01 22:57:17 --> Utf8 Class Initialized
INFO - 2023-04-01 22:57:17 --> URI Class Initialized
INFO - 2023-04-01 22:57:17 --> Router Class Initialized
INFO - 2023-04-01 22:57:17 --> Output Class Initialized
INFO - 2023-04-01 22:57:17 --> Security Class Initialized
DEBUG - 2023-04-01 22:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 22:57:17 --> Input Class Initialized
INFO - 2023-04-01 22:57:17 --> Language Class Initialized
INFO - 2023-04-01 22:57:17 --> Loader Class Initialized
INFO - 2023-04-01 22:57:17 --> Helper loaded: url_helper
INFO - 2023-04-01 22:57:17 --> Helper loaded: form_helper
INFO - 2023-04-01 22:57:17 --> Helper loaded: file_helper
INFO - 2023-04-01 22:57:17 --> Helper loaded: cookie_helper
INFO - 2023-04-01 22:57:17 --> Database Driver Class Initialized
DEBUG - 2023-04-01 22:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 22:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 22:57:17 --> Form Validation Class Initialized
INFO - 2023-04-01 22:57:17 --> Controller Class Initialized
DEBUG - 2023-04-01 22:57:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-04-01 22:57:17 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-01 22:57:17 --> Model "MLogin" initialized
INFO - 2023-04-01 22:57:17 --> Model "Feedmain" initialized
INFO - 2023-04-01 22:57:17 --> Final output sent to browser
DEBUG - 2023-04-01 22:57:17 --> Total execution time: 0.0804
INFO - 2023-04-01 22:58:07 --> Config Class Initialized
INFO - 2023-04-01 22:58:07 --> Hooks Class Initialized
DEBUG - 2023-04-01 22:58:07 --> UTF-8 Support Enabled
INFO - 2023-04-01 22:58:07 --> Utf8 Class Initialized
INFO - 2023-04-01 22:58:07 --> URI Class Initialized
DEBUG - 2023-04-01 22:58:07 --> No URI present. Default controller set.
INFO - 2023-04-01 22:58:07 --> Router Class Initialized
INFO - 2023-04-01 22:58:07 --> Output Class Initialized
INFO - 2023-04-01 22:58:07 --> Security Class Initialized
DEBUG - 2023-04-01 22:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 22:58:07 --> Input Class Initialized
INFO - 2023-04-01 22:58:07 --> Language Class Initialized
INFO - 2023-04-01 22:58:07 --> Loader Class Initialized
INFO - 2023-04-01 22:58:07 --> Helper loaded: url_helper
INFO - 2023-04-01 22:58:07 --> Helper loaded: form_helper
INFO - 2023-04-01 22:58:07 --> Helper loaded: file_helper
INFO - 2023-04-01 22:58:07 --> Helper loaded: cookie_helper
INFO - 2023-04-01 22:58:07 --> Database Driver Class Initialized
DEBUG - 2023-04-01 22:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 22:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 22:58:07 --> Form Validation Class Initialized
INFO - 2023-04-01 22:58:07 --> Controller Class Initialized
DEBUG - 2023-04-01 22:58:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-04-01 22:58:07 --> Model "MLogin" initialized
INFO - 2023-04-01 22:58:07 --> Model "SLogin" initialized
INFO - 2023-04-01 22:58:07 --> File loaded: C:\xampp2\htdocs\anonimly\application\views\main.php
INFO - 2023-04-01 22:58:07 --> Final output sent to browser
DEBUG - 2023-04-01 22:58:07 --> Total execution time: 0.0856
INFO - 2023-04-01 22:58:33 --> Config Class Initialized
INFO - 2023-04-01 22:58:33 --> Hooks Class Initialized
DEBUG - 2023-04-01 22:58:33 --> UTF-8 Support Enabled
INFO - 2023-04-01 22:58:33 --> Utf8 Class Initialized
INFO - 2023-04-01 22:58:33 --> URI Class Initialized
INFO - 2023-04-01 22:58:33 --> Router Class Initialized
INFO - 2023-04-01 22:58:33 --> Output Class Initialized
INFO - 2023-04-01 22:58:33 --> Security Class Initialized
DEBUG - 2023-04-01 22:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 22:58:33 --> Input Class Initialized
INFO - 2023-04-01 22:58:33 --> Language Class Initialized
INFO - 2023-04-01 22:58:33 --> Loader Class Initialized
INFO - 2023-04-01 22:58:33 --> Helper loaded: url_helper
INFO - 2023-04-01 22:58:33 --> Helper loaded: form_helper
INFO - 2023-04-01 22:58:34 --> Helper loaded: file_helper
INFO - 2023-04-01 22:58:34 --> Helper loaded: cookie_helper
INFO - 2023-04-01 22:58:34 --> Database Driver Class Initialized
DEBUG - 2023-04-01 22:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 22:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 22:58:34 --> Form Validation Class Initialized
INFO - 2023-04-01 22:58:34 --> Controller Class Initialized
DEBUG - 2023-04-01 22:58:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-04-01 22:58:34 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-01 22:58:34 --> Model "MLogin" initialized
INFO - 2023-04-01 22:58:34 --> Model "Feedmain" initialized
INFO - 2023-04-01 22:58:34 --> Final output sent to browser
DEBUG - 2023-04-01 22:58:34 --> Total execution time: 0.0625
INFO - 2023-04-01 23:03:01 --> Config Class Initialized
INFO - 2023-04-01 23:03:01 --> Hooks Class Initialized
DEBUG - 2023-04-01 23:03:01 --> UTF-8 Support Enabled
INFO - 2023-04-01 23:03:01 --> Utf8 Class Initialized
INFO - 2023-04-01 23:03:01 --> URI Class Initialized
DEBUG - 2023-04-01 23:03:01 --> No URI present. Default controller set.
INFO - 2023-04-01 23:03:01 --> Router Class Initialized
INFO - 2023-04-01 23:03:01 --> Output Class Initialized
INFO - 2023-04-01 23:03:01 --> Security Class Initialized
DEBUG - 2023-04-01 23:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 23:03:01 --> Input Class Initialized
INFO - 2023-04-01 23:03:01 --> Language Class Initialized
INFO - 2023-04-01 23:03:01 --> Loader Class Initialized
INFO - 2023-04-01 23:03:01 --> Helper loaded: url_helper
INFO - 2023-04-01 23:03:01 --> Helper loaded: form_helper
INFO - 2023-04-01 23:03:01 --> Helper loaded: file_helper
INFO - 2023-04-01 23:03:01 --> Helper loaded: cookie_helper
INFO - 2023-04-01 23:03:01 --> Database Driver Class Initialized
DEBUG - 2023-04-01 23:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 23:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 23:03:01 --> Form Validation Class Initialized
INFO - 2023-04-01 23:03:01 --> Controller Class Initialized
DEBUG - 2023-04-01 23:03:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-04-01 23:03:01 --> Model "MLogin" initialized
INFO - 2023-04-01 23:03:01 --> Model "SLogin" initialized
INFO - 2023-04-01 23:03:01 --> File loaded: C:\xampp2\htdocs\anonimly\application\views\main.php
INFO - 2023-04-01 23:03:01 --> Final output sent to browser
DEBUG - 2023-04-01 23:03:01 --> Total execution time: 0.0661
INFO - 2023-04-01 23:03:32 --> Config Class Initialized
INFO - 2023-04-01 23:03:32 --> Hooks Class Initialized
DEBUG - 2023-04-01 23:03:32 --> UTF-8 Support Enabled
INFO - 2023-04-01 23:03:32 --> Utf8 Class Initialized
INFO - 2023-04-01 23:03:32 --> URI Class Initialized
DEBUG - 2023-04-01 23:03:32 --> No URI present. Default controller set.
INFO - 2023-04-01 23:03:32 --> Router Class Initialized
INFO - 2023-04-01 23:03:32 --> Output Class Initialized
INFO - 2023-04-01 23:03:32 --> Security Class Initialized
DEBUG - 2023-04-01 23:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 23:03:32 --> Input Class Initialized
INFO - 2023-04-01 23:03:32 --> Language Class Initialized
INFO - 2023-04-01 23:03:32 --> Loader Class Initialized
INFO - 2023-04-01 23:03:32 --> Helper loaded: url_helper
INFO - 2023-04-01 23:03:32 --> Helper loaded: form_helper
INFO - 2023-04-01 23:03:32 --> Helper loaded: file_helper
INFO - 2023-04-01 23:03:32 --> Helper loaded: cookie_helper
INFO - 2023-04-01 23:03:32 --> Database Driver Class Initialized
DEBUG - 2023-04-01 23:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 23:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 23:03:32 --> Form Validation Class Initialized
INFO - 2023-04-01 23:03:32 --> Controller Class Initialized
DEBUG - 2023-04-01 23:03:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-04-01 23:03:32 --> Model "MLogin" initialized
INFO - 2023-04-01 23:03:32 --> Model "SLogin" initialized
INFO - 2023-04-01 23:03:32 --> File loaded: C:\xampp2\htdocs\anonimly\application\views\main.php
INFO - 2023-04-01 23:03:32 --> Final output sent to browser
DEBUG - 2023-04-01 23:03:32 --> Total execution time: 0.0770
INFO - 2023-04-01 23:03:51 --> Config Class Initialized
INFO - 2023-04-01 23:03:51 --> Hooks Class Initialized
DEBUG - 2023-04-01 23:03:51 --> UTF-8 Support Enabled
INFO - 2023-04-01 23:03:51 --> Utf8 Class Initialized
INFO - 2023-04-01 23:03:51 --> URI Class Initialized
DEBUG - 2023-04-01 23:03:51 --> No URI present. Default controller set.
INFO - 2023-04-01 23:03:51 --> Router Class Initialized
INFO - 2023-04-01 23:03:51 --> Output Class Initialized
INFO - 2023-04-01 23:03:51 --> Security Class Initialized
DEBUG - 2023-04-01 23:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 23:03:51 --> Input Class Initialized
INFO - 2023-04-01 23:03:51 --> Language Class Initialized
INFO - 2023-04-01 23:03:51 --> Loader Class Initialized
INFO - 2023-04-01 23:03:51 --> Helper loaded: url_helper
INFO - 2023-04-01 23:03:51 --> Helper loaded: form_helper
INFO - 2023-04-01 23:03:51 --> Helper loaded: file_helper
INFO - 2023-04-01 23:03:51 --> Helper loaded: cookie_helper
INFO - 2023-04-01 23:03:51 --> Database Driver Class Initialized
DEBUG - 2023-04-01 23:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 23:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 23:03:51 --> Form Validation Class Initialized
INFO - 2023-04-01 23:03:51 --> Controller Class Initialized
DEBUG - 2023-04-01 23:03:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-04-01 23:03:51 --> Model "MLogin" initialized
INFO - 2023-04-01 23:03:51 --> Model "SLogin" initialized
INFO - 2023-04-01 23:03:51 --> File loaded: C:\xampp2\htdocs\anonimly\application\views\main.php
INFO - 2023-04-01 23:03:51 --> Final output sent to browser
DEBUG - 2023-04-01 23:03:51 --> Total execution time: 0.0738
INFO - 2023-04-01 23:04:49 --> Config Class Initialized
INFO - 2023-04-01 23:04:49 --> Hooks Class Initialized
DEBUG - 2023-04-01 23:04:49 --> UTF-8 Support Enabled
INFO - 2023-04-01 23:04:49 --> Utf8 Class Initialized
INFO - 2023-04-01 23:04:49 --> URI Class Initialized
DEBUG - 2023-04-01 23:04:49 --> No URI present. Default controller set.
INFO - 2023-04-01 23:04:49 --> Router Class Initialized
INFO - 2023-04-01 23:04:49 --> Output Class Initialized
INFO - 2023-04-01 23:04:49 --> Security Class Initialized
DEBUG - 2023-04-01 23:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 23:04:49 --> Input Class Initialized
INFO - 2023-04-01 23:04:49 --> Language Class Initialized
INFO - 2023-04-01 23:04:49 --> Loader Class Initialized
INFO - 2023-04-01 23:04:49 --> Helper loaded: url_helper
INFO - 2023-04-01 23:04:49 --> Helper loaded: form_helper
INFO - 2023-04-01 23:04:49 --> Helper loaded: file_helper
INFO - 2023-04-01 23:04:49 --> Helper loaded: cookie_helper
INFO - 2023-04-01 23:04:49 --> Database Driver Class Initialized
DEBUG - 2023-04-01 23:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 23:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 23:04:49 --> Form Validation Class Initialized
INFO - 2023-04-01 23:04:49 --> Controller Class Initialized
DEBUG - 2023-04-01 23:04:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-04-01 23:04:49 --> Model "MLogin" initialized
INFO - 2023-04-01 23:04:49 --> Model "SLogin" initialized
INFO - 2023-04-01 23:04:49 --> File loaded: C:\xampp2\htdocs\anonimly\application\views\main.php
INFO - 2023-04-01 23:04:49 --> Final output sent to browser
DEBUG - 2023-04-01 23:04:49 --> Total execution time: 0.0914
INFO - 2023-04-01 23:05:27 --> Config Class Initialized
INFO - 2023-04-01 23:05:27 --> Hooks Class Initialized
DEBUG - 2023-04-01 23:05:27 --> UTF-8 Support Enabled
INFO - 2023-04-01 23:05:27 --> Utf8 Class Initialized
INFO - 2023-04-01 23:05:27 --> URI Class Initialized
INFO - 2023-04-01 23:05:27 --> Router Class Initialized
INFO - 2023-04-01 23:05:27 --> Output Class Initialized
INFO - 2023-04-01 23:05:27 --> Security Class Initialized
DEBUG - 2023-04-01 23:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 23:05:27 --> Input Class Initialized
INFO - 2023-04-01 23:05:27 --> Language Class Initialized
INFO - 2023-04-01 23:05:27 --> Loader Class Initialized
INFO - 2023-04-01 23:05:27 --> Helper loaded: url_helper
INFO - 2023-04-01 23:05:27 --> Helper loaded: form_helper
INFO - 2023-04-01 23:05:27 --> Helper loaded: file_helper
INFO - 2023-04-01 23:05:27 --> Helper loaded: cookie_helper
INFO - 2023-04-01 23:05:27 --> Database Driver Class Initialized
DEBUG - 2023-04-01 23:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 23:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 23:05:27 --> Form Validation Class Initialized
INFO - 2023-04-01 23:05:27 --> Controller Class Initialized
DEBUG - 2023-04-01 23:05:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-04-01 23:05:27 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-01 23:05:27 --> Model "MLogin" initialized
INFO - 2023-04-01 23:05:27 --> Model "Feedmain" initialized
INFO - 2023-04-01 23:05:33 --> Final output sent to browser
DEBUG - 2023-04-01 23:05:33 --> Total execution time: 5.7954
INFO - 2023-04-01 23:09:07 --> Config Class Initialized
INFO - 2023-04-01 23:09:07 --> Hooks Class Initialized
DEBUG - 2023-04-01 23:09:07 --> UTF-8 Support Enabled
INFO - 2023-04-01 23:09:07 --> Utf8 Class Initialized
INFO - 2023-04-01 23:09:07 --> URI Class Initialized
DEBUG - 2023-04-01 23:09:07 --> No URI present. Default controller set.
INFO - 2023-04-01 23:09:07 --> Router Class Initialized
INFO - 2023-04-01 23:09:07 --> Output Class Initialized
INFO - 2023-04-01 23:09:07 --> Security Class Initialized
DEBUG - 2023-04-01 23:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 23:09:07 --> Input Class Initialized
INFO - 2023-04-01 23:09:07 --> Language Class Initialized
INFO - 2023-04-01 23:09:07 --> Loader Class Initialized
INFO - 2023-04-01 23:09:07 --> Helper loaded: url_helper
INFO - 2023-04-01 23:09:07 --> Helper loaded: form_helper
INFO - 2023-04-01 23:09:07 --> Helper loaded: file_helper
INFO - 2023-04-01 23:09:07 --> Helper loaded: cookie_helper
INFO - 2023-04-01 23:09:07 --> Database Driver Class Initialized
DEBUG - 2023-04-01 23:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 23:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 23:09:07 --> Form Validation Class Initialized
INFO - 2023-04-01 23:09:07 --> Controller Class Initialized
DEBUG - 2023-04-01 23:09:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-04-01 23:09:07 --> Model "MLogin" initialized
INFO - 2023-04-01 23:09:07 --> Model "SLogin" initialized
INFO - 2023-04-01 23:09:07 --> File loaded: C:\xampp2\htdocs\anonimly\application\views\main.php
INFO - 2023-04-01 23:09:07 --> Final output sent to browser
DEBUG - 2023-04-01 23:09:07 --> Total execution time: 0.0782
INFO - 2023-04-01 23:09:45 --> Config Class Initialized
INFO - 2023-04-01 23:09:45 --> Hooks Class Initialized
DEBUG - 2023-04-01 23:09:45 --> UTF-8 Support Enabled
INFO - 2023-04-01 23:09:45 --> Utf8 Class Initialized
INFO - 2023-04-01 23:09:45 --> URI Class Initialized
INFO - 2023-04-01 23:09:45 --> Router Class Initialized
INFO - 2023-04-01 23:09:45 --> Output Class Initialized
INFO - 2023-04-01 23:09:45 --> Security Class Initialized
DEBUG - 2023-04-01 23:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 23:09:45 --> Input Class Initialized
INFO - 2023-04-01 23:09:45 --> Language Class Initialized
INFO - 2023-04-01 23:09:45 --> Loader Class Initialized
INFO - 2023-04-01 23:09:45 --> Helper loaded: url_helper
INFO - 2023-04-01 23:09:45 --> Helper loaded: form_helper
INFO - 2023-04-01 23:09:45 --> Helper loaded: file_helper
INFO - 2023-04-01 23:09:45 --> Helper loaded: cookie_helper
INFO - 2023-04-01 23:09:45 --> Database Driver Class Initialized
DEBUG - 2023-04-01 23:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 23:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 23:09:45 --> Form Validation Class Initialized
INFO - 2023-04-01 23:09:45 --> Controller Class Initialized
DEBUG - 2023-04-01 23:09:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-04-01 23:09:45 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-01 23:09:45 --> Model "MLogin" initialized
INFO - 2023-04-01 23:09:45 --> Model "Feedmain" initialized
INFO - 2023-04-01 23:09:45 --> Final output sent to browser
DEBUG - 2023-04-01 23:09:45 --> Total execution time: 0.1033
INFO - 2023-04-01 23:10:05 --> Config Class Initialized
INFO - 2023-04-01 23:10:05 --> Hooks Class Initialized
DEBUG - 2023-04-01 23:10:05 --> UTF-8 Support Enabled
INFO - 2023-04-01 23:10:05 --> Utf8 Class Initialized
INFO - 2023-04-01 23:10:05 --> URI Class Initialized
DEBUG - 2023-04-01 23:10:05 --> No URI present. Default controller set.
INFO - 2023-04-01 23:10:05 --> Router Class Initialized
INFO - 2023-04-01 23:10:05 --> Output Class Initialized
INFO - 2023-04-01 23:10:05 --> Security Class Initialized
DEBUG - 2023-04-01 23:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 23:10:05 --> Input Class Initialized
INFO - 2023-04-01 23:10:05 --> Language Class Initialized
INFO - 2023-04-01 23:10:05 --> Loader Class Initialized
INFO - 2023-04-01 23:10:05 --> Helper loaded: url_helper
INFO - 2023-04-01 23:10:05 --> Helper loaded: form_helper
INFO - 2023-04-01 23:10:05 --> Helper loaded: file_helper
INFO - 2023-04-01 23:10:05 --> Helper loaded: cookie_helper
INFO - 2023-04-01 23:10:05 --> Database Driver Class Initialized
DEBUG - 2023-04-01 23:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 23:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 23:10:05 --> Form Validation Class Initialized
INFO - 2023-04-01 23:10:05 --> Controller Class Initialized
DEBUG - 2023-04-01 23:10:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-04-01 23:10:05 --> Model "MLogin" initialized
INFO - 2023-04-01 23:10:05 --> Model "SLogin" initialized
INFO - 2023-04-01 23:10:05 --> File loaded: C:\xampp2\htdocs\anonimly\application\views\main.php
INFO - 2023-04-01 23:10:05 --> Final output sent to browser
DEBUG - 2023-04-01 23:10:05 --> Total execution time: 0.0711
INFO - 2023-04-01 23:10:24 --> Config Class Initialized
INFO - 2023-04-01 23:10:24 --> Hooks Class Initialized
DEBUG - 2023-04-01 23:10:24 --> UTF-8 Support Enabled
INFO - 2023-04-01 23:10:24 --> Utf8 Class Initialized
INFO - 2023-04-01 23:10:24 --> URI Class Initialized
DEBUG - 2023-04-01 23:10:24 --> No URI present. Default controller set.
INFO - 2023-04-01 23:10:24 --> Router Class Initialized
INFO - 2023-04-01 23:10:24 --> Output Class Initialized
INFO - 2023-04-01 23:10:24 --> Security Class Initialized
DEBUG - 2023-04-01 23:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 23:10:24 --> Input Class Initialized
INFO - 2023-04-01 23:10:24 --> Language Class Initialized
INFO - 2023-04-01 23:10:24 --> Loader Class Initialized
INFO - 2023-04-01 23:10:24 --> Helper loaded: url_helper
INFO - 2023-04-01 23:10:24 --> Helper loaded: form_helper
INFO - 2023-04-01 23:10:24 --> Helper loaded: file_helper
INFO - 2023-04-01 23:10:24 --> Helper loaded: cookie_helper
INFO - 2023-04-01 23:10:24 --> Database Driver Class Initialized
DEBUG - 2023-04-01 23:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 23:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 23:10:24 --> Form Validation Class Initialized
INFO - 2023-04-01 23:10:24 --> Controller Class Initialized
DEBUG - 2023-04-01 23:10:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2023-04-01 23:10:24 --> Model "MLogin" initialized
INFO - 2023-04-01 23:10:24 --> Model "SLogin" initialized
INFO - 2023-04-01 23:10:24 --> File loaded: C:\xampp2\htdocs\anonimly\application\views\main.php
INFO - 2023-04-01 23:10:24 --> Final output sent to browser
DEBUG - 2023-04-01 23:10:24 --> Total execution time: 0.0665
INFO - 2023-04-01 23:10:38 --> Config Class Initialized
INFO - 2023-04-01 23:10:38 --> Hooks Class Initialized
DEBUG - 2023-04-01 23:10:38 --> UTF-8 Support Enabled
INFO - 2023-04-01 23:10:38 --> Utf8 Class Initialized
INFO - 2023-04-01 23:10:38 --> URI Class Initialized
INFO - 2023-04-01 23:10:38 --> Router Class Initialized
INFO - 2023-04-01 23:10:38 --> Output Class Initialized
INFO - 2023-04-01 23:10:38 --> Security Class Initialized
DEBUG - 2023-04-01 23:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-01 23:10:38 --> Input Class Initialized
INFO - 2023-04-01 23:10:38 --> Language Class Initialized
INFO - 2023-04-01 23:10:38 --> Loader Class Initialized
INFO - 2023-04-01 23:10:38 --> Helper loaded: url_helper
INFO - 2023-04-01 23:10:38 --> Helper loaded: form_helper
INFO - 2023-04-01 23:10:38 --> Helper loaded: file_helper
INFO - 2023-04-01 23:10:38 --> Helper loaded: cookie_helper
INFO - 2023-04-01 23:10:38 --> Database Driver Class Initialized
DEBUG - 2023-04-01 23:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-01 23:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-01 23:10:38 --> Form Validation Class Initialized
INFO - 2023-04-01 23:10:38 --> Controller Class Initialized
DEBUG - 2023-04-01 23:10:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2023-04-01 23:10:38 --> Session class already loaded. Second attempt ignored.
INFO - 2023-04-01 23:10:38 --> Model "MLogin" initialized
INFO - 2023-04-01 23:10:38 --> Model "Feedmain" initialized
INFO - 2023-04-01 23:10:38 --> Final output sent to browser
DEBUG - 2023-04-01 23:10:38 --> Total execution time: 0.0896
