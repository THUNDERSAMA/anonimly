<?php

defined('BASEPATH') OR exit('No direct script access allowed');


class MainController extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        
        $this->load->library('form_validation');
        $this->load->library('session');
        $this->load->model('Mlogin');
        $this->load->model('Feedmain');
    }
    public function feedload()
    {
       
            $last_ranking = $this->input->post('last_ranking');
            $limit = 5; 
            $this->db->select('posts.*, maskers.SIID, maskers.IMAGES');
            $this->db->from('posts');
            $this->db->join('maskers', 'posts.MASKIND_ID = maskers.MASKING_ID');
            $this->db->where('RATINGS <=', $last_ranking);
            $this->db->where('STATUS', '0');
            $this->db->order_by('RATINGS', 'desc');
            $this->db->limit($limit);
            if (!empty($_POST['loaded_posts'])) {
              $loaded_posts = explode(',', $this->input->post('loaded_posts'));
            // file_put_contents("PST.txt","SC".$loaded_posts);
              $this->db->where_not_in('ID', $loaded_posts);
            }
            
            $query = $this->db->get();
            $posts = $query->result_array();
            foreach ($posts as &$post) {
                $user_id = $post['MASKIND_ID'];
                $user_query = $this->db->get_where('maskers', array('MASKING_ID' => $user_id));
                $user = $user_query->row_array();
                $post['SIID'] = $user['SIID'];
                $post['IMAGES'] = $user['IMAGES'];
            }
            // return the posts as JSON
            file_put_contents("testps.txt","SC".json_encode($posts));
            echo json_encode($posts);
          
    }
    public function postupl()
    {
        //
        // $data = array(
        // 'title' => $this->input->post('title'),
        // 'body' => $this->input->post('body'),
        // 'images' => $this->input->post('media')
        // );
        file_put_contents("testz.txt",json_encode($_POST));
        // $img = imagecreatefromstring(base64_decode($string)); 
        // if($img != false) 
        // { 
        //    imagejpeg($img, '/path/to/new/image.jpg'); 
        
        // } 
        $status=0;
        $imageName=null; 
        if(""!=trim($_POST['image']))
        {
        $imageData = $_POST['image'];
        if (!file_exists('./uploads')) {
            mkdir('./uploads', 0777, true);
        }
        
  $imageName = uniqid().".png"; 
  $imageData = str_replace('data:image/png;base64,', '', $imageData);
  
  $imageData = imagecreatefromstring(base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $imageData)));
  
  $filePath = './uploads/' . $imageName;
  //file_put_contents($filePath, $imageData);
  imagepng($imageData, $filePath);

  $imtmp="C:/xampp2/htdocs/anonimly/uploads/".$imageName;
    
   //explict content detection
   try {
    
    $params = array(
        'media' => new CurlFile($imtmp),
          'models' => 'nudity-2.0,wad,offensive,gore',
        'api_user' => '698900732',
        'api_secret' => 'ccKuinvsL57LJyjsH2Lh',
      );

      $ch = curl_init('https://api.sightengine.com/1.0/check.json');
      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
      $response = curl_exec($ch);
      curl_close($ch);
      
      $output = json_decode($response, true);
     // echo json_encode($output);
      if ($output['status'] == 'success') {
        $nudity = $output['nudity'];
        $weapon = $output['weapon'];
        $alcohol = $output['alcohol'];
        $drugs = $output['drugs'];
        $offensive = $output['offensive'];
        $gore = $output['gore'];
        
        if ($nudity['sexual_activity'] >= 0.5 || $nudity['sexual_display'] >= 0.5 || $nudity['erotica'] >= 0.5 || $nudity['suggestive'] >= 0.5 ||
            $weapon >= 0.5 || $alcohol >= 0.5 || $drugs >= 0.5 || $offensive['prob'] >= 0.5 || $gore['prob'] >= 0.5) {
          
                $status=2;
        } else {
          
          $status=0;
        }
      } else {
      
        echo "Error: " . $output['error']['message'];
      }
   } catch (\Throwable $th) {
    
   }
}
   //ends
     $session_data=$this->session->userdata();
     $data = array(
        'MASKIND_ID'=>get_cookie('cookie_hash'),
        'TITLE' =>$_POST['title'],
        'POST' => base64_encode($_POST['body']),
        'IMAGE' => $imageName,
        'STATUS'=>$status,
        'RATINGS'=>rand(1,10)
        );
        file_put_contents("testz.txt",json_encode($data));
   // $this->load->model('ajax_model');
		$insert = $this->Feedmain->createpost($data);
	//	echo json_encode($insert);
  $response = [
    'status' => $insert,
    'path' => $imageName
  ];
  echo json_encode($response);
}
}
